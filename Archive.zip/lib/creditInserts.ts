export const creditData = [
    {
        "date": "2023-01-03",
        "merchant": "Pharmacy",
        "amount": 265.73,
        "status": "successful",
        "account": "credit",
        "user": "Default"
    },
    {
        "date": "2023-10-17",
        "merchant": "GasStation",
        "amount": 83.59,
        "status": "successful",
        "account": "credit",
        "user": "Default"
    },
    {
        "date": "2023-05-01",
        "merchant": "Restaurant",
        "amount": 33.91,
        "status": "successful",
        "account": "credit",
        "user": "Default"
    },
    {
        "date": "2023-01-18",
        "merchant": "Pharmacy",
        "amount": 153.54,
        "status": "successful",
        "account": "credit",
        "user": "Default"
    },
    {
        "date": "2023-07-11",
        "merchant": "TechStore",
        "amount": 26.06,
        "status": "pending",
        "account": "credit",
        "user": "Default"
    },
    {
        "date": "2023-05-26",
        "merchant": "OnlineMarket",
        "amount": 219.07,
        "status": "pending",
        "account": "credit",
        "user": "Default"
    },
]
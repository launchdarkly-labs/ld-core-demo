export const checkData = [
    {
        "date": "2023-07-24",
        "merchant": "SuperMarket",
        "amount": 336.55,
        "status": "successful"
    },
    {
        "date": "2023-06-01",
        "merchant": "Pharmacy",
        "amount": 13.32,
        "status": "successful"
    },
    {
        "date": "2023-03-23",
        "merchant": "TechStore",
        "amount": 188.35,
        "status": "successful"
    },
    {
        "date": "2023-09-15",
        "merchant": "BookStore",
        "amount": 221.99,
        "status": "pending"
    },
    {
        "date": "2023-06-05",
        "merchant": "TechStore",
        "amount": 105.25,
        "status": "successful"
    },
    {
        "date": "2023-09-17",
        "merchant": "OnlineMarket",
        "amount": 283.56,
        "status": "pending"
    },
    {
        "date": "2023-05-01",
        "merchant": "GasStation",
        "amount": 347.89,
        "status": "successful"
    },
    {
        "date": "2023-10-05",
        "merchant": "SuperMarket",
        "amount": 242.05,
        "status": "successful"
    }
]

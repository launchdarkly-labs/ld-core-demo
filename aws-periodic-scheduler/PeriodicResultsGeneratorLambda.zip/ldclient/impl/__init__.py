from typing import TypeVar

AnyNum = TypeVar('AnyNum', int, float, complex)

VERSION = "9.12.1"  # x-release-please-version
